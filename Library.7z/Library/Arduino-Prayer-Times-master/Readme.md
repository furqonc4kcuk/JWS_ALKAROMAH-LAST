Islamic Prayer Times for Arduino
===========
Tested on Arduino :
- Mega 2560
- Uno

Adabted for arduino from this site: http://praytimes.org/manual/

to run the example, you need to install this library: https://github.com/PaulStoffregen/Time
