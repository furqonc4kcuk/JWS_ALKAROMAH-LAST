This is a library for LED P10 Single Color HUB12 matrix displays and NodeMCU ESP8266

It is based on the DMD library by Southern Storm Software, Pty Ltd.

Written by Bonny Useful.
License, check license.txt for more information

To download. click the DOWNLOADS button in the top right corner, rename the uncompressed folder DMDESP.

Place the DMDESP library folder your <arduinosketchfolder>/libraries/ folder. You may need to create the libraries subfolder if its your first library. Restart the IDE.
